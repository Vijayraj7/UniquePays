<?php

return [
    'message' => 'Din oplevelse på dette websted vil blive forbedret ved at tillade cookies.',
    'agree' => 'Tillad cookies',
];
