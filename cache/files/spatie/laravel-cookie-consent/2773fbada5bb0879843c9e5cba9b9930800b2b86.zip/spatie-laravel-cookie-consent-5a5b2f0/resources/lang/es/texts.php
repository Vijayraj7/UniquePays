<?php

return [
    'message' => 'Su experiencia en este sitio será mejorada con el uso de cookies.',
    'agree' => 'Aceptar',
];
