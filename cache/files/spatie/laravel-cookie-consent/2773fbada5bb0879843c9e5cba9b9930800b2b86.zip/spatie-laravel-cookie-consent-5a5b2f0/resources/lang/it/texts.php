<?php

return [
    'message' => 'Questo sito utilizza i cookies per offrire un\'esperienza migliore all\'utente.',
    'agree' => 'Consenti i cookies',
];
