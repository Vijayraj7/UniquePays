<?php

return [
    'message' => 'Este site utiliza cookies. Ao continuar navegando, você concorda com as condições.',
    'agree' => 'Aceitar',
];
