<?php

return [
    'message' => 'Vòstra experiéncia sul site serà melhora en autorizant los cookies.',
    'agree' => 'Autorizar los cookies',
];
